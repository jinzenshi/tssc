# scheme-pih
Partners in Health -branded Stata scheme for graphs.

## About
The .do file scheme-pih.do will automatically create Stata color styles for PIH Orange, Purple, and Blue, and also create two more colors (Green and Yellow). Each color has a normal (pure brand version), as well as a light and dark version.

The file then creates a Stata scheme by writing the scheme file directly into the users Stata system directory (C:/ado/S). This scheme can then be easily accessed when making graphs, or set as the default scheme within Stata.
