# feigenbaum-stata
stata styles and and schemes

for scheme installation help, see: http://www.fight-entropy.com/2013/01/prettier-graphs-with-less-headache-use.html
